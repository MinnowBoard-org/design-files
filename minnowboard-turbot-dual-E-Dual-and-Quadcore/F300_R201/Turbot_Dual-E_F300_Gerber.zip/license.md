﻿PCB F300_R201 Minnowboard Turbot Dual-E Design Files License.

LICENSE: All posted design files for F4300_R201 Minnowboard Turbot Dual-E are released under Creative Commons Attribution-Share Alike 3.0 Unported license, CC-BY-SA 3.0 (http://creativecommons.org/).

ATTRIBUTIONS: The Minnowboard Turbot Dual-E design derived from MinnowBoard Turbot B designed by ADI Engineering, A Division of Silicom. The Minnowboard Turbot B was derived from minnowboard-v1 as designed by CircuitCo LLC.

FUTURE ATTRIBUTIONS: All derivative works are to be attributed to ADI Engineering, A Division of Silicom and CircuitCo LLC.