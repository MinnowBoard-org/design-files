Adhere to the license requirements called out in license.md

This database is shared between the Dual and Quad Core Variants of Turbot Dual-E_F300_R201. You must use variant manager
to select between the G00 variant (dual core) or the G01 variant (quad core). 

The database was created with MentorGraphics DX Designer and PCB Expedition Version EE7.9.5 Update 22.
 
The zipped folder is called TurbotDualE_F300_R200 which refers to revision F300 of the layout and revision 200 of the schematic. The BOM is at R201. 
