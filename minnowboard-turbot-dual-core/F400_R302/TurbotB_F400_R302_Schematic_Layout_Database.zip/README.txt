Adhere to the license requirements called out in license.md

This database is shared between the Dual and Quad Core Variants of TurbotB_F400_R300. You must use variant manager
to select between the G00 variant (dual core) or the G01 variant (quad core). 

The database was created with MentorGraphics DX Designer and PCB Expedition Version EE7.9.5 Update 22.
